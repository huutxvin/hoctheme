jQuery(function($){
  $(window).scroll(function() {
    var winTop = $(window).scrollTop();
    if (winTop >= 30) {
    	
      $(".site-header").addClass("is-sticky");
    } else {
      $(".site-header").removeClass("is-sticky");
    }
  })
})


/* 
Counter Up
*/
jQuery(function($){
$('.counter').each(function() {
  var $this = $(this),
      countTo = $this.attr('data-count');
  
  $({ countNum: $this.text()}).animate({
    countNum: countTo
  },

  {

    duration: 4000,
    easing:'linear',
    step: function() {
      $this.text(Math.floor(this.countNum));
    },
    complete: function() {
      $this.text(this.countNum);
      //alert('finished');
    }

  });  
  


});
})


jQuery(function($){ 


  $( ".lt-service-item img" ).wrap("<div class='widget_sp_image'></div>");

})





$(document).ready(function() {    
    vert_tabs();
    });
    
    $(window).resize(function(){
        if($('.vertical-tabs').innerWidth() > 608) {
            if($('div.selected').length){
            }else{
                $('div.box:first').addClass('selected');    
            }
        }
    });

function vert_tabs(){
    $('ul.checklist-select li').click(function() {
        var selectID = $(this).attr('id');
        $('ul.checklist-select li').removeClass('active');
        $(this).addClass('active');
        $('div.box').removeClass('selected');
        $('.' + selectID + '-box').addClass('selected');
    });    
}





