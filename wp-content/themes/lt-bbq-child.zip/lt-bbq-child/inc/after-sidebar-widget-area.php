<?php if ( is_active_sidebar( 'after-sidebar-widget-area' ) ) : ?>
	<div class="after-sidebar-widget-area">
		<div class="wrap">
		    <?php dynamic_sidebar( 'after-sidebar-widget-area' ); ?>
		</div>
	</div>
<?php endif; ?>
