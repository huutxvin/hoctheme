<?php if ( is_active_sidebar( 'before-footer' ) ) : ?>
	<div class="before-footer">
		<div class="wrap">
		    <?php dynamic_sidebar( 'before-footer' ); ?>
		</div>
	</div>
<?php endif; ?>
