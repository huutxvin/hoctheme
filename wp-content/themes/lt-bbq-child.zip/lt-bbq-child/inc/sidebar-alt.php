<?php if ( is_active_sidebar( 'sidebar-alt' ) ) : ?>
	<div class="sidebar-alt">
		<div class="wrap">
		    <?php dynamic_sidebar( 'sidebar-alt' ); ?>
		</div>
	</div>
<?php endif; ?>
