<?php if ( is_active_sidebar( 'before-content' ) ) : ?>
	<div class="content">
		<?php dynamic_sidebar( 'before-content' ); ?>
	</div>
<?php endif; ?>

