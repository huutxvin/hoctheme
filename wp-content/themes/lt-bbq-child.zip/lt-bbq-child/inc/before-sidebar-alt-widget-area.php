<?php if ( is_active_sidebar( 'before-sidebar-alt-widget-area' ) ) : ?>
	<div class="before-sidebar-alt-widget-area">
		<div class="wrap">
		    <?php dynamic_sidebar( 'before-sidebar-alt-widget-area' ); ?>
		</div>
	</div>
<?php endif; ?>
