<?php if ( is_active_sidebar( 'after-header-1' ) ) : ?>
<div id="lt-slider" class="featured-background-1">

	    <?php dynamic_sidebar( 'after-header-1' ); ?>

</div>
<?php endif; ?>



<?php if ( is_active_sidebar( 'after-header-2' ) ) : ?>
<div id="lt-about" class="featured-background-2">
	<div class="site-inner container">
	    <?php dynamic_sidebar( 'after-header-2' ); ?>
	</div>
</div>
<?php endif; ?>


<?php if ( is_active_sidebar( 'after-header-10' ) ) : ?>
<div id="lt-daily-menu" class="featured-background-3">
	<div class="site-inner container">
	    <?php dynamic_sidebar( 'after-header-10' ); ?>
	</div>
</div>
<?php endif; ?>


<?php if ( is_active_sidebar( 'after-header-11' ) ) : ?>
<div id="lt-our-menu" class="featured-background-4">
	<div class="site-inner container">
	    <?php dynamic_sidebar( 'after-header-11' ); ?>
	</div>
</div>
<?php endif; ?>


<?php if ( is_active_sidebar( 'after-header-12' ) ) : ?>
<div id="lt-portfolio" class="featured-background-5">
	<div class="site-inner container">
	    <?php dynamic_sidebar( 'after-header-12' ); ?>
	</div>
</div>
<?php endif; ?>



<?php if ( is_active_sidebar( 'after-header-13' ) ) : ?>
<div id="lt-contact" class="featured-background-6">
	<div class="site-inner container">
	    <?php dynamic_sidebar( 'after-header-13' ); ?>
	</div>
</div>
<?php endif; ?>


<?php if ( is_active_sidebar( 'after-header-6' ) ) : ?>
<div id="lt-blog" class="featured-background-7">
	<div class="site-inner container">
	    <?php dynamic_sidebar( 'after-header-6' ); ?>
	</div>
</div>
<?php endif; ?>



<?php if ( is_active_sidebar( 'after-header-4' ) ) : ?>
<div id="lt-testimonial" class="featured-background-8">
	<div class="site-inner container">	
	    <?php dynamic_sidebar( 'after-header-4' ); ?>
	</div>
</div>
<?php endif; ?>



<?php if ( is_active_sidebar( 'after-header-9' ) ) : ?>
<div id="lt-map" class="featured-background-9">

	    <?php dynamic_sidebar( 'after-header-9' ); ?>

</div>
<?php endif; ?>









