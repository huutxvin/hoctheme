<?php if ( is_active_sidebar( 'after-footer' ) ) : ?>
	<div class="after-footer">
		<div class="wrap">
		    <?php dynamic_sidebar( 'after-footer' ); ?>
		</div>
	</div>
<?php endif; ?>
