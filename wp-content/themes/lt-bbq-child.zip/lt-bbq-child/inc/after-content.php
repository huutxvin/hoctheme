<?php if ( is_active_sidebar( 'after-content' ) ) : ?>
	<div class="after-content">
		<div class="wrap">
		    <?php dynamic_sidebar( 'after-content' ); ?>
		</div>
	</div>
<?php endif; ?>
