
<?php if ( is_active_sidebar( 'after-content-sidebar-wrap' ) ) : ?>
	<div class="after-content-sidebar-wrap">
		<div class="wrap">
		    <?php dynamic_sidebar( 'after-content-sidebar-wrap' ); ?>
		</div>
	</div>
<?php endif; ?>
